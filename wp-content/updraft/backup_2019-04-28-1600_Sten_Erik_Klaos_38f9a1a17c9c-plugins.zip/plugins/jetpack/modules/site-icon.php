<?php
/**
 * Deprecated. No longer needed. Site Icons are in Core. 
 *
 * @package Jetpack
 */
