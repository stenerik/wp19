<?php
/**
 * Deprecated alias for Crowdsignal.
 */
