<?php
/**
 * VR Block.
 *
 * @since 7.1.0
 *
 * @package Jetpack
 */

jetpack_register_block( 'jetpack/vr' );
